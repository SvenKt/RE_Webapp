
<?php
require 'registerClass.php';

$admin = new Regist;
$admin->registerUser();

?>